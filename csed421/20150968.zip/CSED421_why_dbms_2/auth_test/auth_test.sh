#!/bin/bash

pip3 install requests
pip3 install pyyaml

python3 check_password.py