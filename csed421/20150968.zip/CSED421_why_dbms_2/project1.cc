//// Copyright 2022 Hyun joon park

#include "./project1.h"

#include <string.h>

#include <algorithm>
#include <fstream>
#include <iostream>
#include <list>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>

// trim from left
inline std::string ltrim(std::string s, const char *t = " \t\n\r\f\v") {
  s.erase(0, s.find_first_not_of(t));
  return s;
}

// trim from right
inline std::string rtrim(std::string s, const char *t = " \t\n\r\f\v") {
  s.erase(s.find_last_not_of(t) + 1);
  return s;
}

// trim from left & right
inline std::string trim(std::string s, const char *t = " \t\n\r\f\v") {
  return ltrim(rtrim(s, t), t);
}

class Customer {
 public:
  enum SEX { MALE, FEMALE };

  static SEX convertToSex(const std::string &str) {
    if (str == "m")
      return MALE;
    else if (str == "f")
      return FEMALE;
    else
      throw std::invalid_argument("not Sex String Value");
  }

 private:
  std::string uname;
  std::string passwd;
  std::string lname;
  std::string fname;
  std::string addr;
  int zone;
  SEX sex;
  int age;
  int limit;
  float balance;
  std::string creaditCard;
  std::string email;
  bool active;

 public:
  static const int PROPERTY_COUNT = 13;

  bool isLivingIn(int zone) { return this->zone == zone; }

  bool isActive() { return this->active; }

  std::string getLname() { return this->lname; }

  Customer(std::string uname, std::string passwd, std::string lname,
           std::string fname, std::string addr, int zone, SEX sex, int age,
           int limit, float balance, std::string creaditCard, std::string email,
           bool active) {
    this->uname = uname;
    this->passwd = passwd;
    this->lname = lname;
    this->fname = fname;
    this->addr = addr;
    this->zone = zone;
    this->sex = sex;
    this->age = age;
    this->limit = limit;
    this->balance = balance;
    this->creaditCard = creaditCard;
    this->email = email;
    this->active = active;
  }
};

class Zonecost {
 private:
  int zoneId;
  std::string zoneDesc;
  float price;

 public:
  static const int PROPERTY_COUNT = 3;

  bool isZoneDescSameWith(const std::string &zoneDesc) {
    return this->zoneDesc == zoneDesc;
  }

  int getZoneId() const { return this->zoneId; }

  Zonecost(int zoneId, std::string zoneDesc, float price) {
    this->zoneId = zoneId;
    this->zoneDesc = zoneDesc;
    this->price = price;
  }
};

class LineItem {
 private:
  std::string uname;
  std::string date;
  std::string time;
  std::string barcode;
  int quantity;
  float price;

 public:
  std::string getUname() { return this->uname; }

  std::string getBarcode() { return this->barcode; }

  static const int PROPERTY_COUNT = 6;

  LineItem(std::string uname, std::string date, std::string time,
           std::string barcode, int quantity, float price) {
    this->uname = uname;
    this->date = date;
    this->time = time;
    this->barcode = barcode;
    this->quantity = quantity;
    this->price = price;
  }
};

class ProductA {
 private:
  std::string barcode;
  float price;
  std::string prodDesc;
  std::string mfg;
  std::string supplier;
  bool taxable;
  std::string category;
  float salePercent;

 public:
  static const int PROPERTY_COUNT = 8;

  std::string getBarcode() { return this->barcode; }

  std::string getProdDesc() { return this->prodDesc; }

  ProductA(std::string barcode, float price, std::string prodDesc,
           std::string mfg, std::string supplier, bool taxable,
           std::string category, float salePercent) {
    this->barcode = barcode;
    this->price = price;
    this->prodDesc = prodDesc;
    this->mfg = mfg;
    this->supplier = supplier;
    this->taxable = taxable;
    this->category = category;
    this->salePercent = salePercent;
  }
};

std::list<Zonecost> getZonecostList(std::ifstream &zonecostFile);

std::list<Customer> getCustomerList(std::ifstream &customerFile);

std::list<LineItem> getLineItemList(std::ifstream &lineItemFile);

std::list<ProductA> getProductAList(std::ifstream &productAFile);

void query1(char *const *argv);

void query2(char *const *argv);

std::map<std::string, std::list<std::string> > getBarcodeToUserListMap(
    std::list<LineItem> lineItemList);

std::list<std::string> getResultBarcodeList(
    std::map<std::string, std::list<std::string> > barcodeToPurchaseCountMap);

void printResultBarcodeList(std::list<ProductA> productAList,
                            std::list<std::string> resultBarcodeList);

int main(int argc, char *argv[]) {
  if (strcmp(argv[1], "q1") == 0) {
    query1(argv);
  } else if (strcmp(argv[1], "q2") == 0) {
    query2(argv);
  } else {
    throw std::invalid_argument("There is no function with that query");
  }

  return 0;
}

// Query #1:
// List all the last names (LNAME) of the active customers that live in Toronto.
//
// You will be provided with a customer and zonecost tables in separate files.
// So your program should be executed as :
//
// <your_binary> q1 <customer.file> <zonecost.file>
//
// ex) ./a.out q1 customer.txt zonecost.txt (on your local directory)
//
//
void query1(char *const *argv) {
  const std::string specificZoneDesc = "Toronto";
  std::ifstream customerFile(argv[2]);
  std::ifstream zonecostFile(argv[3]);

  std::list<Zonecost> zonecostList = getZonecostList(zonecostFile);
  std::list<Customer> customerList = getCustomerList(customerFile);

  auto zonecostIter = find_if(
      begin(zonecostList), end(zonecostList),
      [&](Zonecost p) { return p.isZoneDescSameWith(specificZoneDesc); });
  if (zonecostIter == end(zonecostList)) {
    throw std::invalid_argument("There is no zone with that zoneDesc");
  }

  auto customerIter = customerList.begin();
  for (customerIter = customerList.begin(); customerIter != customerList.end();
       customerIter++) {
    if (customerIter->isLivingIn(zonecostIter->getZoneId()) &&
        customerIter->isActive()) {
      std::cout << customerIter->getLname() << std::endl;
    }
  }
}

std::list<Customer> getCustomerList(std::ifstream &customerFile) {
  std::list<Customer> customerList;
  if (customerFile.is_open()) {
    std::string line;

    unsigned int propertyRangeArray[Customer::PROPERTY_COUNT];
    unsigned int lineCount = 0;
    while (getline(customerFile, line)) {
      lineCount++;

      if (lineCount == 2) {
        std::istringstream lineStream(line);
        std::string token;

        int propertyRangeIndex = 0;
        while (getline(lineStream, token, ' ')) {
          unsigned int size = token.size();
          propertyRangeArray[propertyRangeIndex++] = size;
        }
      } else if (lineCount > 2) {
        std::string propertyArray[Customer::PROPERTY_COUNT];
        unsigned int lineCurrentIndex = 0;
        unsigned int propertyArrayIndex = 0;

        for (unsigned int propertyIndex : propertyRangeArray) {
          propertyArray[propertyArrayIndex++] =
              line.substr(lineCurrentIndex, propertyIndex);
          lineCurrentIndex += (propertyIndex + 1);
        }

        std::string uname = trim(propertyArray[0]);
        std::string passwd = trim(propertyArray[1]);
        std::string lname = trim(propertyArray[2]);
        std::string fname = trim(propertyArray[3]);
        std::string addr = trim(propertyArray[4]);

        int zone = stoi(trim(propertyArray[5]));

        std::string sexString = trim(propertyArray[6]);

        int age = stoi(trim(propertyArray[7]));
        int limit = stoi(trim(propertyArray[8]));
        float balance = stof(trim(propertyArray[9]));
        std::string creaditCard = trim(propertyArray[10]);
        std::string email = trim(propertyArray[11]);
        bool active;
        std::istringstream(trim(propertyArray[12])) >> active;

        Customer customer(uname, passwd, lname, fname, addr, zone,
                          Customer::convertToSex(sexString), age, limit,
                          balance, creaditCard, email, active);
        customerList.push_back(customer);
      }
    }
    customerFile.close();
  }
  return customerList;
}

std::list<Zonecost> getZonecostList(std::ifstream &zonecostFile) {
  std::list<Zonecost> zonecostList;
  if (zonecostFile.is_open()) {
    std::string line;
    unsigned int propertyRangeArray[Zonecost::PROPERTY_COUNT];
    unsigned int lineCount = 0;

    while (getline(zonecostFile, line)) {
      lineCount++;
      if (lineCount == 2) {
        std::istringstream lineStream(line);
        std::string token;

        int propertyRangeIndex = 0;
        while (getline(lineStream, token, ' ')) {
          unsigned int size = token.size();
          propertyRangeArray[propertyRangeIndex++] = size;
        }
      } else if (lineCount > 2) {
        std::string propertyArray[Zonecost::PROPERTY_COUNT];
        unsigned int lineCurrentIndex = 0;
        unsigned int propertyArrayIndex = 0;

        for (unsigned int propertyIndex : propertyRangeArray) {
          propertyArray[propertyArrayIndex++] =
              line.substr(lineCurrentIndex, propertyIndex);
          lineCurrentIndex += (propertyIndex + 1);
        }

        int zoneId = stoi(trim(propertyArray[0]));
        std::string zoneDesc = trim(propertyArray[1]);
        float price = stof(trim(propertyArray[2]));
        Zonecost zonecost(zoneId, zoneDesc, price);
        zonecostList.push_back(zonecost);
      }
    }
    zonecostFile.close();
  }
  return zonecostList;
}

std::list<LineItem> getLineItemList(std::ifstream &lineItemFile) {
  std::list<LineItem> lineItemList;
  if (lineItemFile.is_open()) {
    std::string line;

    unsigned int propertyRangeArray[LineItem::PROPERTY_COUNT];
    unsigned int lineCount = 0;
    while (getline(lineItemFile, line)) {
      lineCount++;

      if (lineCount == 2) {
        std::istringstream lineStream(line);
        std::string token;

        int propertyRangeIndex = 0;
        while (getline(lineStream, token, ' ')) {
          unsigned int size = token.size();
          propertyRangeArray[propertyRangeIndex++] = size;
        }
      } else if (lineCount > 2) {
        std::string propertyArray[LineItem::PROPERTY_COUNT];
        unsigned int lineCurrentIndex = 0;
        unsigned int propertyArrayIndex = 0;

        for (unsigned int propertyIndex : propertyRangeArray) {
          propertyArray[propertyArrayIndex++] =
              line.substr(lineCurrentIndex, propertyIndex);
          lineCurrentIndex += (propertyIndex + 1);
        }

        std::string uname = trim(propertyArray[0]);
        std::string date = trim(propertyArray[1]);
        std::string time = trim(propertyArray[2]);
        std::string barcode = trim(propertyArray[3]);
        int quantity = stoi(trim(propertyArray[4]));
        float price = stof(trim(propertyArray[5]));

        LineItem lineItem(uname, date, time, barcode, quantity, price);
        lineItemList.push_back(lineItem);
      }
    }
    lineItemFile.close();
  }
  return lineItemList;
}

std::list<ProductA> getProductAList(std::ifstream &productAFile) {
  std::list<ProductA> productAList;
  if (productAFile.is_open()) {
    std::string line;

    unsigned int propertyRangeArray[ProductA::PROPERTY_COUNT];
    unsigned int lineCount = 0;
    while (getline(productAFile, line)) {
      lineCount++;

      if (lineCount == 2) {
        std::istringstream lineStream(line);
        std::string token;

        int propertyRangeIndex = 0;
        while (getline(lineStream, token, ' ')) {
          unsigned int size = token.size();
          propertyRangeArray[propertyRangeIndex++] = size;
        }
      } else if (lineCount > 2) {
        std::string propertyArray[ProductA::PROPERTY_COUNT];
        unsigned int lineCurrentIndex = 0;
        unsigned int propertyArrayIndex = 0;

        for (unsigned int propertyIndex : propertyRangeArray) {
          propertyArray[propertyArrayIndex++] =
              line.substr(lineCurrentIndex, propertyIndex);
          lineCurrentIndex += (propertyIndex + 1);
        }

        std::string barcode = trim(propertyArray[0]);
        float price = stof(trim(propertyArray[1]));
        std::string prodDesc = trim(propertyArray[2]);
        std::string mfg = trim(propertyArray[3]);
        std::string supplier = trim(propertyArray[4]);
        bool taxable;
        std::istringstream(trim(propertyArray[5])) >> taxable;
        std::string category = trim(propertyArray[6]);
        float salePercent = stof(trim(propertyArray[7]));

        ProductA productA(barcode, price, prodDesc, mfg, supplier, taxable,
                          category, salePercent);
        productAList.push_back(productA);
      }
    }
    productAFile.close();
  }
  return productAList;
}

// Query #2:
//
// Output the BARCODE and the PRODDESC for each product that has been purchased
// by at least two customers.
//
// In this case you will need the lineitem and products tables, and your program
// should be executed as:
//
// <your_binary> q2 <lineitem.file> <products.file>
//
// ex) ./a.out q2 lineitem.txt products_a.txt (on your local directory)
void query2(char *const *argv) {
  std::ifstream lineItemFile(argv[2]);
  std::ifstream productAFile(argv[3]);

  std::list<LineItem> lineItemList = getLineItemList(lineItemFile);
  std::list<ProductA> productAList = getProductAList(productAFile);

  std::map<std::string, std::list<std::string> > barcodeToPurchaseCountMap =
      getBarcodeToUserListMap(lineItemList);
  std::list<std::string> resultBarcodeList =
      getResultBarcodeList(barcodeToPurchaseCountMap);
  printResultBarcodeList(productAList, resultBarcodeList);
}

void printResultBarcodeList(std::list<ProductA> productAList,
                            std::list<std::string> resultBarcodeList) {
  for (auto &productAIter : productAList) {
    if (find(resultBarcodeList.begin(), resultBarcodeList.end(),
             productAIter.getBarcode()) != resultBarcodeList.end()) {
      std::cout << productAIter.getBarcode() << " "
                << productAIter.getProdDesc() << std::endl;
    }
  }
}

std::list<std::string> getResultBarcodeList(
    std::map<std::string, std::list<std::string> > barcodeToPurchaseCountMap) {
  std::list<std::string> resultBarcodeList;
  for (auto &iter : barcodeToPurchaseCountMap) {
    if (iter.second.size() >= 2) {
      resultBarcodeList.push_back(iter.first);
    }
  }
  return resultBarcodeList;
}

std::map<std::string, std::list<std::string> > getBarcodeToUserListMap(
    std::list<LineItem> lineItemList) {
  std::map<std::string, std::list<std::string> > barcodeToPurchaseCountMap;
  for (auto &lineItemIter : lineItemList) {
    auto iterator = barcodeToPurchaseCountMap.find(lineItemIter.getBarcode());
    if (iterator == barcodeToPurchaseCountMap.end()) {
      std::list<std::string> unameList;
      unameList.push_back(lineItemIter.getUname());
      barcodeToPurchaseCountMap.insert({lineItemIter.getBarcode(), unameList});
    } else {
      std::list<std::string> unameList = iterator->second;

      auto unameIter =
          find(unameList.begin(), unameList.end(), lineItemIter.getUname());
      if (unameIter == unameList.end()) {
        unameList.push_back(lineItemIter.getUname());
      }

      barcodeToPurchaseCountMap.erase(lineItemIter.getBarcode());
      barcodeToPurchaseCountMap.insert({lineItemIter.getBarcode(), unameList});
    }
  }
  return barcodeToPurchaseCountMap;
}
